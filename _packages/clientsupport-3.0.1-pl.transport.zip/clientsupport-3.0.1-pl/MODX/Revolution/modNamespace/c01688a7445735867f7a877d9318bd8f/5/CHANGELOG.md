ClientSupport 3.0.0
==============
- Updated ClientSupport to MODX3
- Added german translations #2
- Fixed bug which caused URL to not be included in email

ClientSupport 1.1.0
==============
- Add 'custom_icon' system setting to allow custom icons for clientsupport button
- Improve compatibility for modx3
- Add 'Page URL' static field to popup form

ClientSupport 1.0.0
==============
- First public release

ClientSupport 0.1.6
==============
- Add StercExtra resolver + setup options

ClientSupport 0.1.5
==============
- Update Zendesk logo
- Fix some styling issues
- Add email validation to email field

ClientSupport 0.1.4
==============
- Added branding icons for menu icon

ClientSupport 0.1.3
==============
- Auto-populate the name and emailaddress with MODX user fullname and email
- Add branding for ticket systems Zendesk, Freshdesk and JIRA.

ClientSupport 0.1.2
==============
- Remove hardcoded emailaddress

ClientSupport 0.1.1
==============
- Added dutch translation

ClientSupport 0.1.0
==============
- Initial release.